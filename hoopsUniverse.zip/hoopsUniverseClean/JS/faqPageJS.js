$(document).ready(function(){
    $(".slide").click(function(){
        $(".slideDes").slideToggle("slow");
    });
});